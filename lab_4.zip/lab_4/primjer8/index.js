const net = require('net');

var server=net.createServer(connection=>{
    

});

server.listen(3000);